Jonathan Cheng Cote

All the files are in the same folder. I ran it by opening two terminals.  Run Make first.

First terminal command
$ server localhost:2250


Second terminal command
$ client localhost:2250 notes


The terminals will display the relevant information.
A file named output.txt will be created that will contain a copy of the file that was entered through the client.
